class ToastContext
{
  static COLORS = ['#00539CFF', '#EEA47FFF', '#2F3C7E', '#FBEAEB',
                   '#101820FF', '#FEE715FF', '#F96167', '#FCE77D',
                   '#CCF381', '#4831D4', '#317773', '#E2D1F9',
                   '#8AAAE5', '#FF69B4', '#00FFFF', '#FCEDDA',
                   '#EE4E34', '#ADD8E6', '#00008b', '#E3B448'];
  
  constructor(direction = 'left') {
    this.NOTIF_STYLE = document.createElement('style');
    this.NOTIF_CONTAINER = document.createElement('div');
    
    this.NOTIF_STYLE.type = 'text/css';
    this.direction_coeff = direction == 'left' ? -1 : 1;
    this.NOTIF_STYLE.innerHTML = `
    .notif {
      position: relative;
      
      display: inline-block;
      width: fit-content;
      max-width: 30vw;
      margin: 5px;
      transform: translateX(${this.direction_coeff * 200}%);
      padding: 5px;
      
      border-radius: 1px;
      box-shadow: black 2px 2px 3px;
      background-color: white;
      z-index: 999;
      animation-name: animstart;
      animation-duration: 0.7s;
      animation-fill-mode: forwards;
      animation-timing-function: cubic-bezier(0, 1.21, 0.33, 1.29);
    }

    @keyframes animstart {
      100% {
        transform: translateX(${-this.direction_coeff * 5}%);
      }
    }
      
    .notif_container {
      display: flex;
      flex-direction: column;
      align-items: left;
      z-index: 999;
      position: fixed;
      top: 0px;
      ${direction == 'left' ? 'left: 0px' : 'right: 0px'};
    }`;
    
    document.head.appendChild(this.NOTIF_STYLE);
      
    this.NOTIF_CONTAINER.setAttribute('class', 'notif_container');
    document.body.appendChild(this.NOTIF_CONTAINER);

  }
  
  displayMessageToast(message, time = 5, callback, options) {
    options = Object.assign({
      color: 'random', // can be any valid css color or random
      showProgress: true // can be made false to avoid the progress
    }, options);
    
    // create the element
    let elem = document.createElement('div');
    elem.setAttribute('class', 'notif');
    elem.innerText = message;
    
    // element click behaviour
    elem.onclick = callback ? () => {
      callback(elem);
    } : () => {elem.remove()};
    
    this.NOTIF_CONTAINER.appendChild(elem); // append to view
    
    // element time behaviour
    if (time < 0) {
      // will be indefinitely present
      return;
    }
    
    // auto deletion of element
    setTimeout(() => {
      elem.animate(
        [
          { // to
            transform: 'translateX(' + this.direction_coeff * 200 + '%)'
          }
        ], 300);
      setTimeout(() => elem.remove(), 300);
    }, time * 1000);
    
    // do not create progress if disallowed
    if(!options.showProgress) return;
    
    let selcolor = options.color == 'random' ? 
      ToastContext.COLORS[parseInt(Math.random() * ToastContext.COLORS.length)] : 
      options.color;
      
    // progress bar animation
    let progress = document.createElement('span');
    progress.style = `
      width: 100%;
      height: 5px;
      background-color: ${selcolor};
      position: absolute;
      bottom: 0px;
      left: 0px;
      z-index: -1;`;
    
    progress.animate(
      [
        { // to
          width: '0px'
        }
      ], 
      {
        duration: time * 1000,
        fill: 'forwards'
      });
      
    elem.append(progress);
  }
  
  displayTemplateMessage(templateId, time = 5, callback, options) {
    options = Object.assign({
      color: 'random', // can be any valid css color or random
      showProgress: true // can be made false to avoid the progress
    }, options);
    
    let elem = document.getElementById(templateId);
    let clone = elem.content.cloneNode(true);
    
    // create the element
    let toast = document.createElement('div');
    toast.setAttribute('class', 'notif');
    toast.append(clone);
    
    // element click behaviour
    toast.onclick = callback ? () => {
      callback(toast);
    } : () => {toast.remove()};
    
    this.NOTIF_CONTAINER.appendChild(toast); // append to view
    
    if(time < 0) {
      // will be indefinitely present
      return;
    }
    
    setTimeout(() => {
      toast.animate(
        [
          { // to
            transform: 'translateX(' + this.direction_coeff * 200 + '%)'
          }
        ], 300);
      setTimeout(() => toast.remove(), 300);
    }, time * 1000);
    
    // do not create progress if disallowed
    if(!options.showProgress) return;
    
    let selcolor = options.color == 'random' ? 
      ToastContext.COLORS[parseInt(Math.random() * ToastContext.COLORS.length)] : 
      options.color;
    
    // progress bar animation
    let progress = document.createElement('span');
    progress.style = `
      width: 100%;
      height: 5px;
      background-color: ${selcolor};
      
      position: absolute;
      bottom: 0px;
      left: 0px;
      z-index: -1;`;
    
    progress.animate(
      [
        { // to
          width: '0px'
        }
      ],
      {
        duration: time * 1000,
        fill: 'forwards'
      });
      
    toast.append(progress);
  }
}
