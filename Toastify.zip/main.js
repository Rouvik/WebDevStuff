let cxt = new ToastContext('right');
const but = document.getElementById('but1');
let i = 0;
but.onclick = () => {
  cxt.displayMessageToast('Toast number: ' + i++);
}

cxt.displayTemplateMessage('test');